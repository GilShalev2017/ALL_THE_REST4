export let categoriesData = [
    {
        "name": "Theaters"
    },
    {
        "name": "Restaurants"
    },
    {
        "name": "Pharmacies"
    },
    {
        "name": "Museums"
    },
    {
        "name": "Markets"
    },
    {
        "name": "Gasoline Stations"
    },
    {
        "name": "Fashion Shops"
    },
    {
        "name": "Cinemas"
    }
];