#!/bin/bash

# bash stops processing once it encounters the error
#set -e

exec java -Djava.library.path="/usr/local/lib" -Dapp.logs.path="/opt/app" -jar intel-cloudfreed-kvcdemoworker.jar -s gilbqkndeyyemv_stadium_cameras_5 -ss EARLIEST -r eu-west-1 -o "/opt/{0,number,#}.264" -save false -useProxy false