package com.intel.cloudfreed.kvcdemoworker;


import com.intel.cloudfreed.kvcdemoworker.framevisitor.FrameProcessor;
import org.junit.Test;

import javax.xml.bind.annotation.adapters.HexBinaryAdapter;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 * Unit test for simple App.
 */
public class AppTest
{
    @Test
    public void calcSHA1_DifferentInput_ReturnsDifferentResults() throws Exception
    {
        ByteBuffer buffer1 = ByteBuffer.wrap(new byte[]{1,1,1,1});
        ByteBuffer buffer2 = ByteBuffer.wrap(new byte[]{2,2,2,2});
        String result1 = FrameProcessor.calcSHA1(buffer1);
        String result2 = FrameProcessor.calcSHA1(buffer2);
    }

}