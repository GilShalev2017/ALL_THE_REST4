package com.intel.cloudfreed.kvcdemoworker;


import com.amazonaws.kinesisvideo.parser.mkv.MkvElementVisitor;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.kinesis.AmazonKinesis;
import com.amazonaws.services.kinesis.AmazonKinesisClientBuilder;
import com.amazonaws.services.kinesisvideo.model.StartSelector;
import com.amazonaws.services.kinesisvideo.model.StartSelectorType;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.intel.cloudfreed.kvcdemoworker.helpers.AmazonKinesisVideoMediaFactory;
import com.intel.cloudfreed.kvcdemoworker.helpers.ConfigConstants;
import com.intel.cloudfreed.kvcdemoworker.framevisitor.ElementVisitorFactory;
import com.intel.cloudfreed.kvcdemoworker.helpers.IAmazonKinesisVideoMediaFactory;
import com.intel.cloudfreed.kvcdemoworker.storage.FakeStorage;
import com.intel.cloudfreed.kvcdemoworker.storage.FileStorage;
import com.intel.cloudfreed.kvcdemoworker.storage.IStorage;
import com.intel.cloudfreed.framecomposer.interfaces.IFrameComposer;
import com.intel.cloudfreed.framecomposer.jnihpci.JniHpciFrameComposer;

import org.apache.commons.cli.*;

import org.apache.commons.lang.StringUtils;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.nio.file.Files;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class App
{
    private static ILoggerFactory _loggerFactory = LoggerFactory.getILoggerFactory();
    private static Logger _logger = _loggerFactory.getLogger(App.class.toString());;


    public static void main( String[] args ) throws Exception
    {
        System.out.println("Kinesis Video Consumer Demo Worker");

        java.security.Security.setProperty("networkaddress.cache.ttl" , "60");

        Config appConfig = null;

        try
        {
            appConfig = GetConfig(args);
        }
        catch (Exception ex)
        {
            System.exit(1);
        }

        // kinesis factory config
        Properties awsConfig = new Properties();
        awsConfig.put(ConfigConstants.AWS_REGION, appConfig.getRegion());

        // kinesis video
        IAmazonKinesisVideoMediaFactory videoKinesisFactory = new AmazonKinesisVideoMediaFactory(appConfig.getStreamName(), awsConfig, appConfig.getUseIntelProxy());
        StartSelector startSelector = new StartSelector().withStartSelectorType(StartSelectorType.fromValue(appConfig.getStartSelector())); // StartSelectorType.EARLIEST // NOW

        // frame composer
        //IFrameComposer composer = new JniHpciFrameComposer();
        IFrameComposer composer = new JniHpciFrameComposer();


        // storage
        IStorage storage = new FileStorage();
        //IStorage storage = new FakeStorage();


        // visitor
        MkvElementVisitor elementVisitor = new ElementVisitorFactory(0, appConfig.getOutputPath(), composer, storage, _loggerFactory, appConfig.getSaveEncodedFrames(),
                appConfig.getStopAtFrameId(), appConfig.getStopAfterXFrames()).create();

        // worker
        Runnable worker = new KvcDemoWorker(_loggerFactory, videoKinesisFactory, startSelector, appConfig.getStreamName(), elementVisitor);


        ExecutorService executorService = Executors.newFixedThreadPool(1);
        executorService.submit(worker)
                .get(); // await ...


        if (!executorService.isTerminated()) {
            _logger.warn("Shutting down executor service by force");
            executorService.shutdownNow();
        }
        else {
            _logger.info("Executor service is shutdown");
        }
    }

    private static Config GetConfig(String[] args ) throws Exception
    {
        Config result = new Config();
        // use environment variable first
        result.setRegion(System.getenv("AWS_REGION"));

        String ARG_CONFIG ="config";
        String ARG_STREAM_NAME ="stream-name";
        String ARG_START_SELECTOR ="start-selector";
        String ARG_OUTPUT ="output";
        String ARG_REGION ="region";
        String ARG_SAVE_ENCODED_FRAMES ="save";
        String ARG_USE_INTEL_PROXY ="useProxy";

        String ARG_STOP_AFTER_FRAME_ID ="stopAtFrameId";
        String ARG_STOP_AFTER_X_FRAMES ="stopAfterXFrames";

        String ARG_PROGRAMS_BUCKET ="programsBucket";
        String ARG_PROGRAMS_BUCKET_REGION ="programsBucketRegion";
        String ARG_BASE_KEY ="baseKey";

        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        Options options = new Options();
        CommandLine cmd = null;

        options.addOption(new Option("c", ARG_CONFIG, true, "file path to 'config.json'"));
        options.addOption(new Option("s", ARG_STREAM_NAME, true, "kinesis video stream name"));
        options.addOption(new Option("ss", ARG_START_SELECTOR, true, "kinesis selector 'NOW' or 'EARLIEST'"));
        options.addOption(new Option("o", ARG_OUTPUT, true, "output directory full path ex: 'c:\\temp\\frame-{0,number,#}.h264'"));
        options.addOption(new Option("r", ARG_REGION, true, "AWS region name ex: 'eu-west-1'"));
        options.addOption(new Option("save", ARG_SAVE_ENCODED_FRAMES, true, "Save Encoded frames ex: 'true / false'"));
        options.addOption(new Option("useProxy", ARG_USE_INTEL_PROXY, true, "Use Intel's Proxy ex: 'true / false'"));

        options.addOption(new Option("stopAtFrameId", ARG_STOP_AFTER_FRAME_ID, true, "Stop after frames id'"));
        options.addOption(new Option("stopAfterXFrames", ARG_STOP_AFTER_X_FRAMES, true, "Stop after x frames'"));

        options.addOption(new Option("programsBucket", ARG_STOP_AFTER_X_FRAMES, true, "programs bucket'"));
        options.addOption(new Option("programsBucketRegion", ARG_STOP_AFTER_X_FRAMES, true, "region of the programs bucket'"));
        options.addOption(new Option("baseKey", ARG_STOP_AFTER_X_FRAMES, true, "baseKey - folder(s) inside bucket'"));

        try
        {
            cmd = parser.parse(options, args);

            if(cmd.hasOption(ARG_CONFIG))
            {
                String configPath = cmd.getOptionValue(ARG_CONFIG);

                if(configPath == null || configPath.isEmpty())
                {
                    throw new Exception("invalid arguments value");
                }

                File configFile = new File(configPath);

                if(!configFile.exists() || configFile.isDirectory())
                {
                    throw new Exception("file not exists");
                }

                List<String> fileLines = Files.readAllLines(configFile.toPath());
                String jsonString = StringUtils.join(fileLines, StringUtils.EMPTY);

                ObjectMapper jsonMapper = new ObjectMapper();
                result = jsonMapper.readValue(jsonString, Config.class);
            }
            else
            {
                result.setStreamName(cmd.getOptionValue(ARG_STREAM_NAME));
                result.setStartSelector(cmd.getOptionValue(ARG_START_SELECTOR));
                result.setOutputPath(cmd.getOptionValue(ARG_OUTPUT));

                if(!isNullOrEmpty(cmd.getOptionValue(ARG_REGION)))
                {
                    result.setRegion(cmd.getOptionValue(ARG_REGION));
                }

                result.setSaveEncodedFrames(true);

                if(!isNullOrEmpty(cmd.getOptionValue(ARG_SAVE_ENCODED_FRAMES)))
                {
                    String saveEncodedFramesString = cmd.getOptionValue(ARG_SAVE_ENCODED_FRAMES).toLowerCase();

                    if(saveEncodedFramesString.equals("false"))
                    {
                        result.setSaveEncodedFrames(false);
                    }
                }

                result.setUseIntelProxy(false);

                if(!isNullOrEmpty(cmd.getOptionValue(ARG_USE_INTEL_PROXY)))
                {
                    String useProxyString = cmd.getOptionValue(ARG_USE_INTEL_PROXY).toLowerCase();

                    if(useProxyString.equals("true"))
                    {
                        result.setUseIntelProxy(true);
                    }
                }

                result.setStopAtFrameId(-1);

                if(!isNullOrEmpty(cmd.getOptionValue(ARG_STOP_AFTER_FRAME_ID)))
                {
                    long stopAtFrameId = Long.parseLong(cmd.getOptionValue(ARG_STOP_AFTER_FRAME_ID));

                    result.setStopAtFrameId(stopAtFrameId);
                }

                result.setStopAfterXFrames(-1);

                if(!isNullOrEmpty(cmd.getOptionValue(ARG_STOP_AFTER_X_FRAMES)))
                {
                    int stopAfterXFrames = Integer.parseInt(cmd.getOptionValue(ARG_STOP_AFTER_X_FRAMES));

                    result.setStopAfterXFrames(stopAfterXFrames);
                }

                result.setProgramsBucket(null);

                if(!isNullOrEmpty(cmd.getOptionValue(ARG_PROGRAMS_BUCKET)))
                {
                    String programsBucket = cmd.getOptionValue(ARG_PROGRAMS_BUCKET);

                    result.setProgramsBucket(programsBucket);
                }

                result.setProgramsBucketRegion(null);

                if(!isNullOrEmpty(cmd.getOptionValue(ARG_PROGRAMS_BUCKET_REGION)))
                {
                    String programsBucketRegion = cmd.getOptionValue(ARG_PROGRAMS_BUCKET_REGION);

                    result.setProgramsBucketRegion(programsBucketRegion);
                }

                result.setBaseKey(null);

                if(!isNullOrEmpty(cmd.getOptionValue(ARG_BASE_KEY)))
                {
                    String baseKey = cmd.getOptionValue(ARG_BASE_KEY);

                    result.setBaseKey(baseKey);
                }
            }

            // validation
            if(isNullOrEmpty(result.getStreamName()) || isNullOrEmpty(result.getRegion()) || isNullOrEmpty(result.getStartSelector())|| isNullOrEmpty(result.getOutputPath()))
            {
                throw new Exception("invalid arguments value");
            }

        }
        catch (Exception e)
        {
            System.out.println("Error: " +e.getMessage());
            formatter.printHelp("You can use config.json or Args", options);


            throw new Exception("GetConfig Exception");
        }

        return result;
    }

    public static boolean isNullOrEmpty(String str) {
        if(str != null && !str.trim().isEmpty())
            return false;
        return true;
    }
}
