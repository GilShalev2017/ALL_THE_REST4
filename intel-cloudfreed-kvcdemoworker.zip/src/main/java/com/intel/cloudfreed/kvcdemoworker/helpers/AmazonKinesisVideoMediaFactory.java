package com.intel.cloudfreed.kvcdemoworker.helpers;


import com.amazonaws.ClientConfiguration;
import com.amazonaws.Protocol;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.auth.profile.ProfileCredentialsProvider;
import com.amazonaws.auth.InstanceProfileCredentialsProvider;
import com.amazonaws.client.builder.AwsClientBuilder;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.kinesisvideo.AmazonKinesisVideo;
import com.amazonaws.services.kinesisvideo.AmazonKinesisVideoClientBuilder;
import com.amazonaws.services.kinesisvideo.AmazonKinesisVideoMedia;
import com.amazonaws.services.kinesisvideo.AmazonKinesisVideoMediaClientBuilder;
import com.amazonaws.services.kinesisvideo.model.APIName;
import com.amazonaws.services.kinesisvideo.model.GetDataEndpointRequest;

import java.util.Properties;

public class AmazonKinesisVideoMediaFactory implements IAmazonKinesisVideoMediaFactory
{
    private String _streamName;
    private Properties _config;
    private static boolean _useIntelProxy;

    public AmazonKinesisVideoMediaFactory(String streamName, Properties config, boolean useIntelProxy)
    {
        _streamName = streamName;
        _config = config;
        _useIntelProxy = useIntelProxy;
    }

    public AmazonKinesisVideoMedia create() throws Exception
    {
        validate(_config);

        AWSCredentialsProvider credentials = DefaultAWSCredentialsProviderChain.getInstance(); // by default AWS credentials chain.
        Regions region = Regions.fromName(_config.getProperty(ConfigConstants.AWS_REGION));


        if(_config.containsKey(ConfigConstants.AWS_PROFILE_NAME))
        {
            credentials = new ProfileCredentialsProvider(_config.getProperty(ConfigConstants.AWS_PROFILE_NAME));
        }
        else if(_config.containsKey(ConfigConstants.AWS_ACCESS_KEY_ID) && _config.containsKey(ConfigConstants.AWS_SECRET_ACCESS_KEY) )
        {
            credentials = new BasicAWSCredentialsProvider(_config.getProperty(ConfigConstants.AWS_ACCESS_KEY_ID), _config.getProperty(ConfigConstants.AWS_SECRET_ACCESS_KEY));
        }

        AmazonKinesisVideo kinesisClient;

        if(_useIntelProxy == true) {
            ClientConfiguration clientConfiguration = new ClientConfiguration();
            clientConfiguration.setProxyHost("proxy.iil.intel.com");
            clientConfiguration.setProtocol(Protocol.HTTPS);
            clientConfiguration.setProxyPort(911);

            kinesisClient = AmazonKinesisVideoClientBuilder.standard()
                    .withClientConfiguration(clientConfiguration)
                    .withCredentials(credentials)
                    .withRegion(region)
                    .build();
        }
        else
        {
            kinesisClient = AmazonKinesisVideoClientBuilder.standard()
                    .withCredentials(credentials)
                    .withRegion(region)
                    .build();
        }

        AmazonKinesisVideoMedia mediaClient = AmazonKinesisVideoMediaFactory.create(_streamName, region, credentials, kinesisClient);

        return  mediaClient;
    }

    // helper method
    public static AmazonKinesisVideoMedia create(String streamName, Regions region, AWSCredentialsProvider credentialsProvider, AmazonKinesisVideo amazonKinesisVideo)
    {
        String endPoint = amazonKinesisVideo.getDataEndpoint(new GetDataEndpointRequest().withAPIName(APIName.GET_MEDIA).withStreamName(streamName)).getDataEndpoint();

        AmazonKinesisVideoMediaClientBuilder builder;

        if(_useIntelProxy == true) {
            ClientConfiguration clientConfiguration = new ClientConfiguration();
            clientConfiguration.setProxyHost("proxy.iil.intel.com");
            clientConfiguration.setProtocol(Protocol.HTTPS);
            clientConfiguration.setProxyPort(911);

            builder = AmazonKinesisVideoMediaClientBuilder
                    .standard()
                    .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(endPoint, region.getName()))
                    .withCredentials(credentialsProvider)
                    .withClientConfiguration(clientConfiguration);
        }
        else
        {
            builder = AmazonKinesisVideoMediaClientBuilder
                    .standard()
                    .withEndpointConfiguration(new AwsClientBuilder.EndpointConfiguration(endPoint, region.getName()))
                    .withCredentials(credentialsProvider);
        }

        return builder.build();
    }

    private static void validate(Properties config) throws Exception
    {
        if(config.getProperty(ConfigConstants.AWS_REGION) == null || config.getProperty(ConfigConstants.AWS_REGION) == "")
        {
            throw new Exception(ConfigConstants.AWS_REGION + " can't be null or empty");
        }
    }
}
