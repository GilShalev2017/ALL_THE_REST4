package com.intel.cloudfreed.kvcdemoworker.storage;

import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class FakeStorage implements IStorage {

    public void save(String filaPath, ByteBuffer blob) throws Exception
    {
        // do nothing..
    }
}

