package com.intel.cloudfreed.kvcdemoworker;

import com.amazonaws.kinesisvideo.parser.ebml.InputStreamParserByteSource;
import com.amazonaws.kinesisvideo.parser.mkv.MkvElementVisitor;
import com.amazonaws.kinesisvideo.parser.mkv.StreamingMkvReader;
import com.amazonaws.services.kinesisvideo.AmazonKinesisVideoMedia;
import com.amazonaws.services.kinesisvideo.model.GetMediaRequest;
import com.amazonaws.services.kinesisvideo.model.GetMediaResult;
import com.amazonaws.services.kinesisvideo.model.StartSelector;
import com.intel.cloudfreed.kvcdemoworker.helpers.IAmazonKinesisVideoMediaFactory;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;


import java.io.Closeable;
import java.io.IOException;

public class KvcDemoWorker implements Runnable, Closeable
{
    private Logger _logger;
    private String _streamName;
    private StartSelector _startSelector;
    private AmazonKinesisVideoMedia _videoMediaClient;
    private MkvElementVisitor _elementVisitor;
    private volatile boolean _isRunning;

    public KvcDemoWorker(ILoggerFactory loggerFactory, IAmazonKinesisVideoMediaFactory clientFactory, StartSelector startSelector, String streamName, MkvElementVisitor elementVisitor) throws Exception
    {
        _logger = loggerFactory.getLogger(KvcDemoWorker.class.toString());
        _videoMediaClient = clientFactory.create();
        _streamName = streamName;
        _startSelector = startSelector;
        _elementVisitor = elementVisitor;
    }

    // Primitive Runnable implementation
    public void run()
    {
        _logger.info("Running KvsDemoWorker");

        _isRunning = true;

        try
        {
            runExec();
        }
        catch (Exception ex)
        {
            _logger.error("Error while running worker", ex);
        }

        try
        {
            close();
        }
        catch (Exception ex)
        {
            _logger.error("Error while closing", ex);
        }
    }


    private void runExec() throws Exception
    {
        while(_isRunning)
        {
            if (Thread.currentThread().isInterrupted()) {
                throw new Exception("Aborted exception");
            }

            GetMediaResult result = _videoMediaClient.getMedia(new GetMediaRequest().withStreamName(_streamName).withStartSelector(_startSelector));
            _logger.debug("GetMedia called on stream {} response {} requestId {}", _streamName, result.getSdkHttpMetadata().getHttpStatusCode(), result.getSdkResponseMetadata().getRequestId());

            StreamingMkvReader mkvStreamReader = StreamingMkvReader.createDefault(new InputStreamParserByteSource(result.getPayload()));
            _logger.debug("StreamingMkvReader created for stream {} ", _streamName);

            // start the reader. The reader will stop running only when cancel() or close() is called, or an error is thrown.
            mkvStreamReader.apply(_elementVisitor);
        }
    }


    public void close() throws IOException
    {
        _logger.debug("Closing DecoderWorker");

        _isRunning = false;

        try
        {
            if (_videoMediaClient != null)
            {
                _videoMediaClient.shutdown();
            }
        }
        catch (Exception ex)
        {
            throw new RuntimeException("Error while closing Kinesis Video Media client", ex);
        }
    }
}
