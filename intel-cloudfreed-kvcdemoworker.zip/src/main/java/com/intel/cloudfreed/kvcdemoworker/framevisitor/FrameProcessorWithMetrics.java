package com.intel.cloudfreed.kvcdemoworker.framevisitor;

import com.amazonaws.kinesisvideo.parser.mkv.Frame;
import com.amazonaws.kinesisvideo.parser.utilities.FragmentMetadata;
import com.amazonaws.kinesisvideo.parser.utilities.FragmentMetadataVisitor;
import com.amazonaws.kinesisvideo.parser.utilities.FrameVisitor;
import com.amazonaws.kinesisvideo.parser.utilities.MkvTrackMetadata;
import com.google.common.base.Stopwatch;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;

import java.time.Clock;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class FrameProcessorWithMetrics<T> implements FrameVisitor.FrameProcessor
{
    private FrameVisitor.FrameProcessor _inner;
    private Logger _logger = null;

    private long _avgFps;
    private int _fpsCounter;
    LinkedList<Integer> _fpsHistory = new LinkedList<Integer>();

    private long _lastCallTime = Clock.systemUTC().millis();

    public FrameProcessorWithMetrics(FrameVisitor.FrameProcessor inner, ILoggerFactory loggerFactory)
    {
        _inner = inner;
        _logger = loggerFactory.getLogger(FrameProcessorWithMetrics.class.toString());

        TimerTask fpsMetricTask = new TimerTask() {
            public void run() {

                if(_fpsHistory.size() == 3) { // keep max 3 items
                    _fpsHistory.removeFirst();
                }
                _fpsHistory.add(_fpsCounter);

                _avgFps = (long)Arrays.stream(_fpsHistory.stream().mapToInt(Integer::intValue).toArray()).average().getAsDouble();

                _fpsCounter = 0; // reset counter
            }
        };

        new Timer("fps").scheduleAtFixedRate(fpsMetricTask, 1000L, 1000L);
    }


    // TODO: generate AWS CloudWatch metrics
    public void process(Frame frame, MkvTrackMetadata trackMetadata, Optional<FragmentMetadata> fragmentMetadata, Optional<FragmentMetadataVisitor.MkvTagProcessor> tagProcessor)
    {
        _fpsCounter++;

        long timeStart = Clock.systemUTC().millis();

        _inner.process(frame, trackMetadata, fragmentMetadata, tagProcessor);

        long timeAfter = Clock.systemUTC().millis();

        long _downloadDelay = Clock.systemUTC().millis() - _lastCallTime - (timeAfter - timeStart);

        _lastCallTime = Clock.systemUTC().millis();

        _logger.info("Statistics: download delay: "+ _downloadDelay +" (ms), frame process time taken: " + (timeAfter - timeStart) + " (ms), FPS: " + _avgFps);
    }
}
