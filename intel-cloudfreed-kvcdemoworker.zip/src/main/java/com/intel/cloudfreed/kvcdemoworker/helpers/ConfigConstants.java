package com.intel.cloudfreed.kvcdemoworker.helpers;


public class ConfigConstants
{
    public static final String AWS_REGION = "region";
    public static final String AWS_PROFILE_NAME = "profile";
    public static final String AWS_ACCESS_KEY_ID = "access-key-id";
    public static final String AWS_SECRET_ACCESS_KEY = "secret-access-key";
}
