package com.intel.cloudfreed.kvcdemoworker.helpers;

import com.amazonaws.services.kinesisvideo.AmazonKinesisVideoMedia;

public interface IAmazonKinesisVideoMediaFactory
{
    AmazonKinesisVideoMedia create() throws Exception;;
}