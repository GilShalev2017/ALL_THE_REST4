package com.intel.cloudfreed.kvcdemoworker.framevisitor;

import com.amazonaws.kinesisvideo.parser.utilities.FragmentMetadataVisitor;
import com.amazonaws.kinesisvideo.parser.utilities.FrameVisitor;
import com.intel.cloudfreed.kvcdemoworker.storage.IStorage;
import com.intel.cloudfreed.framecomposer.interfaces.IFrameComposer;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;

import java.util.Optional;


public class ElementVisitorFactory
{
    private ILoggerFactory _loggerFactory = null;
    private IFrameComposer _composer = null;
    private IStorage _storage = null;
    private int _cameraId;
    private String _outputAddress;
    private boolean _saveEncodedFrames;
    private long _stopAfterFrameId;
    private int _stopAfterXFrames;

    public ElementVisitorFactory(int cameraId, String outputAddress, IFrameComposer composer, IStorage storage, ILoggerFactory loggerFactory, boolean saveEncodedFrames, long stopAfterFrameId, int stopAfterXFrames)
    {
        _cameraId = cameraId;
        _outputAddress = outputAddress;
        _composer = composer;
        _storage = storage;
        _loggerFactory = loggerFactory;
        _saveEncodedFrames = saveEncodedFrames;
        _stopAfterFrameId = stopAfterFrameId;
        _stopAfterXFrames = stopAfterXFrames;
    }

    public FrameVisitor create()
    {
        FrameVisitor.FrameProcessor innerFrameProcessor = new FrameProcessor(_cameraId, _outputAddress, _composer, _storage,_loggerFactory, _saveEncodedFrames, _stopAfterFrameId, _stopAfterXFrames);

        FrameProcessorWithMetrics frameProcessorWithMetrics = new FrameProcessorWithMetrics(innerFrameProcessor, _loggerFactory);

        FragmentMetadataVisitor.MkvTagProcessor tagProcessor =  new FragmentMetadataVisitor.BasicMkvTagProcessor();

        return FrameVisitor.create(frameProcessorWithMetrics, Optional.of(tagProcessor));

        //return FrameVisitor.create(new FrameProcessorWithMetrics(new FrameProcessor(_cameraId, _outputAddress, _composer, _storage, _loggerFactory), _loggerFactory));
    }
}
