package com.intel.cloudfreed.kvcdemoworker.storage;

import java.nio.ByteBuffer;

public interface IStorage
{
    void save(String filaPath, ByteBuffer blob) throws Exception;
}
