package com.intel.cloudfreed.kvcdemoworker;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.io.Serializable;

public @Data @AllArgsConstructor @NoArgsConstructor class Config implements Serializable
{
    private String outputPath;
    private String streamName;
    private String startSelector;
    private String region;
    private Boolean saveEncodedFrames;
    private Boolean useIntelProxy;

    private long stopAtFrameId;
    private int stopAfterXFrames;

    private String programsBucket;
    private String programsBucketRegion;
    private String baseKey;
}
