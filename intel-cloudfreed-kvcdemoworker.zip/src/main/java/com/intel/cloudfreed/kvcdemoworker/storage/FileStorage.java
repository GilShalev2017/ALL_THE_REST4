package com.intel.cloudfreed.kvcdemoworker.storage;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

public class FileStorage implements IStorage {


    public void save(String filaPath, ByteBuffer blob) throws Exception
    {
        blob.rewind();

        FileChannel fc = new FileOutputStream(filaPath).getChannel();
        fc.write(blob);
        fc.close();

        blob.rewind();
    }
}
