package com.intel.cloudfreed.kvcdemoworker.framevisitor;

import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.handlers.AsyncHandler;
import com.amazonaws.kinesisvideo.parser.mkv.Frame;
import com.amazonaws.kinesisvideo.parser.utilities.FragmentMetadata;
import com.amazonaws.kinesisvideo.parser.utilities.FragmentMetadataVisitor;
import com.amazonaws.kinesisvideo.parser.utilities.FrameVisitor;
import com.amazonaws.kinesisvideo.parser.utilities.MkvTrackMetadata;
import com.amazonaws.regions.Regions;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBAsync;
import com.amazonaws.services.dynamodbv2.AmazonDynamoDBAsyncClientBuilder;
import com.amazonaws.services.dynamodbv2.model.AttributeValue;
import com.amazonaws.services.dynamodbv2.model.PutItemRequest;
import com.amazonaws.services.dynamodbv2.model.PutItemResult;
import com.intel.cloudfreed.kvcdemoworker.storage.IStorage;
import com.intel.cloudfreed.framecomposer.interfaces.GetMetaResult;
import com.intel.cloudfreed.framecomposer.interfaces.IFrameComposer;

import org.redisson.Redisson;
import org.redisson.api.RScoredSortedSet;
import org.redisson.api.RedissonClient;
import org.redisson.client.RedisClient;
import org.redisson.client.RedisConnection;
import org.redisson.client.codec.StringCodec;
import org.redisson.client.protocol.RedisCommands;
import org.redisson.config.Config;
import org.slf4j.ILoggerFactory;
import org.slf4j.Logger;
import redis.clients.jedis.Jedis;
import sun.nio.cs.UTF_32LE;

import javax.xml.bind.annotation.adapters.HexBinaryAdapter;
import java.io.Console;
import java.nio.ByteBuffer;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.MessageFormat;
import java.time.Clock;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

public class FrameProcessor<T> implements FrameVisitor.FrameProcessor
{
    private Logger _logger = null;
    private Logger _integrity = null;
    private Logger _latency = null;

    private IFrameComposer _composer = null;
    private IStorage _storage = null;
    private int _cameraId;
    private String _outputAddress;
    private boolean _saveEncodedFrames;
    private AmazonDynamoDBAsync _dynamoDbClient;
    private HashMap<String, AttributeValue> _ddb_item_values;

    private int _frameCounter = 0;
    private int _savedFrameCounter = 0;
    private long _lastFrame = 0;
    private long _stopAfterFrameId;
    private int _stopAfterXFrames;

    public FrameProcessor(int cameraId, String outputAddress, IFrameComposer composer, IStorage storage, ILoggerFactory loggerFactory, boolean saveEncodedFrames, long stopAfterFrameId, int stopAfterXFrames)
    {
        _cameraId = cameraId;
        _outputAddress = outputAddress;
        _composer = composer;
        _storage = storage;
        _logger = loggerFactory.getLogger(FrameProcessor.class.toString());
        _integrity = loggerFactory.getLogger("integrity");
        _latency = loggerFactory.getLogger("latency");
        _saveEncodedFrames = saveEncodedFrames;
        _stopAfterFrameId = stopAfterFrameId;
        _stopAfterXFrames = stopAfterXFrames;
        //_dynamoDbClient = CreateMyClient();
        //_ddb_item_values = new HashMap<String, AttributeValue>();
    }

    public void process(Frame frame, MkvTrackMetadata trackMetadata, Optional<FragmentMetadata> fragmentMetadata, Optional<FragmentMetadataVisitor.MkvTagProcessor> tagProcessor)
    {
        _logger.debug("process frame: " + frame);
        _logger.debug("process frame trackMetadata: " + trackMetadata);
        _logger.debug("process frame fragmentMetadata: " + fragmentMetadata);

        try
        {
            _logger.debug("tagProcessor: " + tagProcessor);

//            FragmentMetadataVisitor.BasicMkvTagProcessor mkvTagProcessor = (FragmentMetadataVisitor.BasicMkvTagProcessor) tagProcessor.get();
//            List<MkvTag> tags = mkvTagProcessor.getTags();
//            MkvTag cameraIDTag = tags.get(0);
//            String cameraID = cameraIDTag.getTagValue();

            processFrame(frame.getFrameData());
        }
        catch (Exception ex)
        {
            _logger.error("Error while processing frame", ex);
        }
    }
    private static Map<String, AttributeValue> CreateFrameRecordPutRequest(long frameID, long timeStamp, String gameID, int cameraId)
    {
        Map<String, AttributeValue> frameRecordItem = new HashMap<String, AttributeValue>();

        String pk = gameID + "_" + cameraId;
        frameRecordItem.put("pk", new AttributeValue(pk));
        frameRecordItem.put("game_id", new AttributeValue(gameID));
        frameRecordItem.put("camera_id", new AttributeValue(String.valueOf(cameraId)));
        frameRecordItem.put("frame_id", new AttributeValue(String.valueOf(frameID)));
        frameRecordItem.put("time_stamp", new AttributeValue(String.valueOf(timeStamp)));

        return frameRecordItem;
    }

    private void saveFrameInRedis(long frameID)
    {
        try {

            //Jedis client123 = new Jedis("retransmit-redis-cluster.iluenw.ng.0001.use1.cache.amazonaws.com", 6379);
//            Jedis client123 = new Jedis("gil-decoder-cluster.oi8hjl.ng.0001.euw1.cache.amazonaws.com",6379);
//
//            client123.set("events/city/rome", "32,15,223,828");
//            String cachedResponse = client123.get("events/city/rome");

            //RedisClient client = new RedisClient("retransmit-redis-cluster.iluenw.ng.0001.use1.cache.amazonaws.com", 6379);
            RedisClient client = new RedisClient("gil-decoder-cluster.oi8hjl.ng.0001.euw1.cache.amazonaws.com", 6379);
            RedisConnection conn = client.connect();
            conn.sync(StringCodec.INSTANCE, RedisCommands.SET, "test", 0);

            conn.closeAsync();
            client.shutdown();

            Config config = new Config();
            config.useSingleServer()
                    .setAddress("retransmit-redis-cluster.iluenw.ng.0001.use1.cache.amazonaws.com:6379");

            RedissonClient client2 = Redisson.create(config);

            String _game_id = "";
            long _camera_id = 0;

            String sortedSet = _game_id + "_" + _camera_id;

            RScoredSortedSet rScoredSortedSet = client2.getScoredSortedSet(sortedSet);

            rScoredSortedSet.add(frameID, frameID);
        }
        catch (Exception xcp)
        {
            int i=3;
        }
    }

    private void addDdbRecord(long frameID, long timeStamp, int cameraId, String gameID) {
        try {
            String pk = gameID + "_" + cameraId;

            PutItemRequest putItemRequest = new PutItemRequest();
            putItemRequest.setTableName("retransmit-api-dev-3");

            _ddb_item_values.put("pk", new AttributeValue(pk));
            _ddb_item_values.put("game_id", new AttributeValue(gameID));
            _ddb_item_values.put("camera_id", new AttributeValue(String.valueOf(cameraId)));
            _ddb_item_values.put("frame_id", new AttributeValue(String.valueOf(frameID)));
            _ddb_item_values.put("time_stamp", new AttributeValue(String.valueOf(timeStamp)));

            putItemRequest.setItem(_ddb_item_values);

            //TODO decide if to use the sync or async method!
            //_dynamoDbClient.putItemAsync("retransmit-api-dev-3", _ddb_item_values);
            PutItemResult res = _dynamoDbClient.putItem("retransmit-api-dev-3", _ddb_item_values);

//            _dynamoDbClient.putItemAsync(putItemRequest, new AsyncHandler<PutItemRequest, PutItemResult>() {
//                public void onSuccess(PutItemRequest request, final PutItemResult recordResult) {
//                    _savedFrameCounter++;
//                }
//                public void onError(final java.lang.Exception iexc) {
//                    int i=3;
//                }
//            });
        }
        catch (Exception exception) {
            int i=4;
        }
    }
    private static AmazonDynamoDBAsync CreateMyClient()
    {
        AWSCredentialsProvider credentials = DefaultAWSCredentialsProviderChain.getInstance(); // by default AWS credentials chain.
        //Regions region = Regions.fromName("eu-west-1");
        Regions region = Regions.fromName("us-east-1");
        //credentials = new BasicAWSCredentialsProvider(_config.getProperty(ConfigConstants.AWS_ACCESS_KEY_ID), _config.getProperty(ConfigConstants.AWS_SECRET_ACCESS_KEY));
        AmazonDynamoDBAsyncClientBuilder builder = AmazonDynamoDBAsyncClientBuilder.standard();
        builder.withRegion(region);
        builder.withCredentials(credentials);
        return builder.build();
    }

    private void processFrame(ByteBuffer frame) throws Exception
    {
        // parse header
        GetMetaResult meta = _composer.getMeta(frame);
        frame.rewind(); // reset position to '0'.

        // print log
        _logger.info("frame meta: " + meta);

        // compose file Path
        System.out.println("_outputAddress = " + _outputAddress);
        String filePath = MessageFormat.format(_outputAddress, meta.getFrameId());

        // save decoded frame
        if(_saveEncodedFrames == true) {
            System.out.println("File PATH  = " + filePath);
            _storage.save(filePath, frame);
        }

        // print integrity log
        //TimeStamp that is populated by the frame grabber is in microseconds. timeNow - retreived by this java application
        //is in milliseconds. In order to align the units, we need to divide the first by 1000.
        double frameGrabberTimeStamp = meta.getTimeStamp();
        double frameGrabberTimeStampInMillis = frameGrabberTimeStamp / 1000.0;
        double consumerAppTimeStampMillis = Clock.systemUTC().millis();
        double deltaInMilliSeconds = consumerAppTimeStampMillis - frameGrabberTimeStampInMillis;
        String sha1 = calcSHA1(frame).toLowerCase();

        _latency.info(MessageFormat.format("frame_id = {0,number,#}, frameGrabberTimeStampMillis = {1,number,#}, consumerAppTimeStampMillis = {2,number,#}, latency = {3,number,#}",
                meta.getFrameId(), frameGrabberTimeStampInMillis, consumerAppTimeStampMillis, deltaInMilliSeconds));

        _integrity.info(MessageFormat.format("frame_id = {0,number,#} , SHA-1 = {1}",
                meta.getFrameId(), sha1));

        long frameId = meta.getFrameId();

        if((frameId - 1) != _lastFrame)
        {
            System.out.println("currentFrameID: " + frameId + " lastFrameID: " + _lastFrame);
        }

        //saveFrameInRedis(frameId);

        _lastFrame = frameId;
        _frameCounter++;

       // addDdbRecord(frameId, (long)frameGrabberTimeStamp,_cameraId,"my-game-id");

        if(_stopAfterXFrames != -1  && _frameCounter == _stopAfterXFrames)
        {
            System.out.println("Stopped after " + _stopAfterXFrames + " frames");
            System.exit(-1);
        }

        if(_stopAfterFrameId != -1  && frameId == _stopAfterFrameId)
        {
            System.out.println("Stopped at frame ID " + _stopAfterFrameId);
            System.exit(-1);
        }
    }

    public static String calcSHA1(ByteBuffer frame) throws NoSuchAlgorithmException {

        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        sha1.reset();
        sha1.update(frame);

        return new HexBinaryAdapter().marshal(sha1.digest());
    }

    // this one does not copy
    // ByteBuffer rawFrame = ByteBuffer.wrap(frame.array(), (int)meta.getBodyOffset(), frame.remaining() - (int)meta.getBodyOffset());

}
