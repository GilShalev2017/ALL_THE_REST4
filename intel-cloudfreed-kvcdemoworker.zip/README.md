# FreeD cloud Kinesis Video Consumer Demo Worker (KvcDemoWorker) 
A simple java conspole app with the next flow:
*   Get frame from Kinesis Video (according to start selector `NOW` or `EARLIEST`)
*   Extract (parse) meta data of frame (`frameId`, `timeStamp` etc..)
*   If configured to true - Save frame as is in provided output direcotry
*   Generate integrity & latency logs files. See configuration part in order to set path directory.

### Download
You can get prebuild version from S3 [temp1-file-share/builds/intel-cloudfreed-kvcdemoworker-1.3.zip](https://s3-eu-west-1.amazonaws.com/temp1-file-share/builds/1.4.0/Ubuntu/intel-cloudfreed-kvcdemoworker-1.4.zip 
or https://s3-eu-west-1.amazonaws.com/temp1-file-share/builds/1.4.0/Windows/intel-cloudfreed-kvcdemoworker-1.4.zip and https://s3-eu-west-1.amazonaws.com/temp1-file-share/builds/1.4.0/Dependencies). (in future Artifactory).

### Dependencies
This java library depends on [libIntel.CloudFreed.FrameComposer.JniHpciFrameComposer (.so / .dll)](https://bitbucket.il.alm-sg.com/projects/RP/repos/intel.cloudfreed.framecomposer.jnihpciframecomposer/browse) file which is actual implementation of composer. 


### Compile  
Run command `mvn package` it will generate jar with dependencies under `./target/` folder.


### Config 
There are two options to provide configuration either through `arguments` or via `config.json` file.
In addition you have to configure **AWS SDK** credentials.
We use [Default Credential Provider Chain](https://docs.aws.amazon.com/sdk-for-java/v1/developer-guide/credentials.html) (which support Roles , Profiles, Environment variables) so you have planty of variants how to do it.
*   For `Region` you can use Environment variable `AWS_REGION` as well.
*   For integrity & latency logs path use java parameter `-Dapp.logs.path="/var/logs/kvcdemoworker"`

#### Args example:
```
usage: You can use config.json or Args
 -c,--config <arg>            file path to 'config.json'
 -o,--output <arg>            output directory full path ex:
                              'c:\temp\frame-{0,number,#}.data'
 -r,--region <arg>            AWS region name ex: 'eu-west-1'
 -s,--stream-name <arg>       kinesis video stream name
 -ss,--start-selector <arg>   kinesis selector 'NOW' or 'EARLIEST'
 -save <arg>   to save / not encoded files: use 'true' or 'false' the default is true (no need to set the default)
 -useProxy <arg> to use /not intel's proxy: use 'true' or 'false' the default is false (no need to set the default)
 ```

#### config.json example:
Use argument `-c --config` in order to provide full path to the config.json. 
```
{
    "streamName": "name",
    "region": "eu-west-1",
    "startSelector": "NOW", // 'NOW' or 'EARLIEST'
    "outputPath":"D:\\temp\\frames\\{0,number,#}.data",
	"save": "false",
	"useProxy": "true"
}
```


### Running
```
// On Linux:
export LD_LIBRARY_PATH=/dir/to/lib   // ex: /usr/local/lib
java -Dapp.logs.path="/var/logs/kvcdemoworker" -jar intel-cloudfreed-kvcdemoworker.jar -s video-stream-name -ss EARLIEST -r eu-west-1 -o "/home/ubuntu/out/{0,number,#}.data" -save false -useProxy true
```
OR with `-Djava.library.path`
```
// On Windows
java -Dapp.logs.path="D:/logs/kvcdemoworker" -Djava.library.path="C:\path\to\lib" -jar intel-cloudfreed-kvcdemoworker.jar -s video-stream-name -ss EARLIEST -r eu-west-1 -o  "C:\temp\output\{0,number,#}.data"
```
Example:
```
java -Dapp.logs.path="D:/logs/kvcdemoworker" -Djava.library.path="D:\builds\Intel.CloudFreed.FrameComposer.JniHpciFrameComposer\win-x64\debug" -jar intel-cloudfreed-kvcdemoworker-1.4.jar -s ms1_trial_source_0 -ss EARLIEST -r eu-west-1 -o "D:\temp\output\{0,number,#}.data"
```



