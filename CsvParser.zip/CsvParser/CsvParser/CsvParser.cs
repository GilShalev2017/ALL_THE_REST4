﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;

namespace CsvParser
{
    public class CsvParser : IEnumerable
    {
        List<CsvRow> _rows;

        public CsvParser(string fileName)
        {
            ParseCsvFile(fileName);
        }

        private void ParseCsvFile(string fileName)
        {
            _rows = new List<CsvRow>();

            bool isFirstLine = true;

            string[] columnNames = new string[3];

            foreach (string line in File.ReadLines(fileName))
            {
                string[] cells = line.Split(',');

                if (isFirstLine)
                {
                    columnNames = new string[cells.Length];

                    cells.CopyTo(columnNames, 0);

                    isFirstLine = false;
                }
                else
                {
                    var newRow = new CsvRow();

                    for (int i = 0; i < cells.Length; i++)
                    {
                        newRow[columnNames[i]] = cells[i];
                    }

                    _rows.Add(newRow);
                }
            }
        }

        public bool IsEmpty
        {
            get { return _rows.Count == 0 ? true : false; }
        }

        public int Count
        {
            get { return _rows.Count; }
        }

        public CsvRow this[int i]
        {
            get
            {
                return _rows[i];
            }
            set
            {
                _rows[i] = value;
            }
        }

        public List<CsvRow> WhereEquals(string propertyName, string value)
        {
            List<CsvRow> matches = new List<CsvRow>();

            foreach (CsvRow row in _rows)
            {
                if (row[propertyName] == value)
                {
                    matches.Add(row);
                }
            }

            return matches;
        }

        public List<CsvRow> WhereEquals(string propertyName, int value)
        {
            List<CsvRow> matches = new List<CsvRow>();

            foreach (CsvRow row in _rows)
            {
                int result;

                if (int.TryParse(row[propertyName], out result))
                {
                    if (result == value)
                    {
                        matches.Add(row);
                    }
                }
            }

            return matches;
        }

        public List<CsvRow> WhereEquals(string propertyName, double value)
        {
            List<CsvRow> matches = new List<CsvRow>();

            foreach (CsvRow row in _rows)
            {
                if (double.TryParse(row[propertyName], out double result))
                {
                    if (result == value)
                    {
                        matches.Add(row);
                    }
                }
            }

            return matches;
        }

        public List<CsvRow> WhereGreaterThan(string propertyName, int value)
        {
            List<CsvRow> matches = new List<CsvRow>();

            foreach (CsvRow row in _rows)
            {
                if (int.TryParse(row[propertyName], out int result))
                {
                    if (result > value)
                    {
                        matches.Add(row);
                    }
                }
            }

            return matches;
        }

        public List<CsvRow> WhereGreaterThan(string propertyName, double value)
        {
            List<CsvRow> matches = new List<CsvRow>();

            foreach (CsvRow row in _rows)
            {
                if (double.TryParse(row[propertyName], out double result))
                {
                    if (result > value)
                    {
                        matches.Add(row);
                    }
                }
            }

            return matches;
        }

        public List<CsvRow> WhereLessThan(string propertyName, int value)
        {
            List<CsvRow> matches = new List<CsvRow>();

            foreach (CsvRow row in _rows)
            {
                if (int.TryParse(row[propertyName], out int result))
                {
                    if (result < value)
                    {
                        matches.Add(row);
                    }
                }
            }

            return matches;
        }

        List<CsvRow> WhereLessThan(string propertyName, double value)
        {
            List<CsvRow> matches = new List<CsvRow>();

            foreach (CsvRow row in _rows)
            {
                if (double.TryParse(row[propertyName], out double result))
                {
                    if (result < value)
                    {
                        matches.Add(row);
                    }
                }
            }

            return matches;
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return (IEnumerator)GetEnumerator();
        }

        public CsvRowEnumerator GetEnumerator()
        {
            return new CsvRowEnumerator(_rows.ToArray());
        }
    }

    public class CsvRowEnumerator : IEnumerator
    {
        public CsvRow[] _rows;

        int position = -1;

        public CsvRowEnumerator(CsvRow[] list)
        {
            _rows = list;
        }

        public bool MoveNext()
        {
            position++;
            return (position < _rows.Length);
        }

        public void Reset()
        {
            position = -1;
        }

        object IEnumerator.Current
        {
            get
            {
                return Current;
            }
        }

        public dynamic Current
        {
            get
            {
                try
                {
                    return _rows[position];
                }
                catch (IndexOutOfRangeException)
                {
                    throw new InvalidOperationException();
                }
            }
        }
    }
}
