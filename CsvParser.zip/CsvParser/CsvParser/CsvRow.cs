﻿using System.Collections.Generic;
using System.Dynamic;

namespace CsvParser
{
    public class CsvRow : DynamicObject
    {
        private Dictionary<string, string> _dictionary;

        public CsvRow()
        {
            _dictionary = new Dictionary<string, string>();
        }

        public string this[string propertyName]
        {
            get
            {
                return _dictionary[propertyName];
            }
            set
            {
                _dictionary[propertyName] = value;
            }
        }

        public override bool TryGetMember(GetMemberBinder binder, out object result)
        {
            if (!_dictionary.TryGetValue(binder.Name, out string data))
            {
                throw new KeyNotFoundException("There's no key by that name");
            }

            result = data;

            return true;
        }

        public override bool TrySetMember(SetMemberBinder binder, object value)
        {
            if (_dictionary.ContainsKey(binder.Name))
            {
                _dictionary[binder.Name] = (string)value;
            }
            else
            {
                _dictionary.Add(binder.Name, (string)value);
            }

            return true;
        }
    }
}
