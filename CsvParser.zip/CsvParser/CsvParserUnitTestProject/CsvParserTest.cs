﻿using System.Collections.Generic;
using CsvParser;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace CsvParserUnitTestProject
{
    [TestClass]
    public class CsvParserTest
    {
        [TestMethod]
        public void TestCsvParserMethods()
        {
            CsvParser.CsvParser csv = new CsvParser.CsvParser("myfile.csv");

            Assert.AreEqual(csv.IsEmpty, false, "expected csv with data but found none");

            Assert.AreEqual(csv.Count, 4, "expected 4 rows but found different number");

            List<CsvRow> matches = csv.WhereEquals("result", "OK");

            Assert.AreEqual(matches.Count, 1, "expected one occurence, but found different value");

            matches = csv.WhereGreaterThan("status", 200);

            Assert.AreEqual(matches.Count, 3, "expected 3 occurences, but found different value");

            matches = csv.WhereLessThan("status", 500);

            Assert.AreEqual(matches.Count, 3, "expected 3 occurences, but found different value");

            Assert.AreEqual(csv[1]["result"], "Moved Permanently", "strings should be the same");

            dynamic row = csv[3];

            Assert.AreEqual(row.result, "Internal Server Error", "strings should be the same");

            Assert.AreEqual(row.status, "500", "strings should be the same");
        }
    }
}
